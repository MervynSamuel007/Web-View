package com.papag.nevergiveup

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var login = findViewById<EditText>(R.id.editTextTextEmailAddress)
        var password = findViewById<EditText>(R.id.editTextTextPassword)

        var Button = findViewById<Button>(R.id.button)

        //Button
        Button.setOnClickListener {
            val username = login.text.toString()
            var pass = password.text.toString()
            println("user " + username + " Password " + pass)
            if (username == "sam") {
                if (pass == "123") {
                    Toast.makeText(applicationContext, "LOGIN Sucessful", Toast.LENGTH_LONG).show()
                   // startActivity(Intent(this, MapsActivity::class.java))
                } else if (pass == "321") {
                    Toast.makeText(applicationContext, "user sam pwd 321", Toast.LENGTH_LONG).show()
                    startActivity(Intent(this, neverever::class.java))
                } else {
                    Toast.makeText(applicationContext, "Password unmatch", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(applicationContext, "Username unmatch", Toast.LENGTH_LONG).show()
            }
        }

    }
}